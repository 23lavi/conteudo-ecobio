// database.js
const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'sistema_login'
});

connection.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados:', err);
    } else {
        console.log('Conectado ao banco de dados MySQL');
    }
});

module.exports = connection;

// server.js
const express = require('express');
const bodyParser = require('body-parser');
const connection = require('./database');

const app = express();
const PORT = 3000;

// Middleware para servir arquivos estáticos e processar dados do formulário
app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({ extended: true }));

// Rota para exibir o formulário HTML
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
});

// Rota para processar o cadastro
app.post('/cadastrar', (req, res) => {
    const { nome, email, senha } = req.body;

    const query = 'INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)';
    connection.query(query, [nome, email, senha], (err, results) => {
        if (err) {
            console.error('Erro ao cadastrar usuário:', err);
            res.send('Erro ao cadastrar usuário');
        } else {
            res.send('Usuário cadastrado com sucesso!');
        }
    });
});

// Inicia o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});

